
[![XEVAL BANNER](https://cdn.discordapp.com/attachments/449845125816909834/454314336610025472/1528387411445.png)](https://discord.io/gspace)

-----

[![Discord Bots](https://discordbots.org/api/widget/441667160025333762.svg)](https://discordbots.org/bot/441667160025333762)
 ---

[![COMPPERS COMMUNTY](https://cdn.discordapp.com/attachments/449192179571752981/453083394038038538/Commpers-community.gif)](https://discord.gg/comppers)

- Этот бот защищен блэт.

- За копирование бота или кода вас ждет лютый пиздэц блэд.

----

[![zashita suka](https://cdn.discordapp.com/attachments/419546915408052235/449931989869395978/Screenshot_2018-05-26-16-36-28.jpg)](https://cdn.discordapp.com/attachments/419546915408052235/449931989869395978/Screenshot_2018-05-26-16-36-28.jpg)

**©| XeVAL |**

**Наебал, защиты нет, или есть? 🤔**
